# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '2.0.0.dev0'
__hash__ = '0433d88100b3cd43ff9b4fa854ffcfeb5465b15c'
__date__ = '20190724'
